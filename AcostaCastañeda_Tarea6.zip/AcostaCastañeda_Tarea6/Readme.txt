Para la parte I:
Los algoritmos de Dijkstra,
Bellman Ford y Floyd Warschall estan en sus clases que llevan sus nombres.
Para correrlos, en consola se despliega que debes escoger entre un numero de uno al 6 el cual significa que txt quieres correr.
Este imprimira el tiempo que se demora y la matriz con sus costos minimos.

Para la parte II:
El algoritmo que implementa BFS  para hallar componentes se ejecuta desde 
la clase Main  dentro del paquete "Parte II" pasando por argumento por 
linea de comandos el nombre del archivo que se va a ejecutar,se tienen 
2 archivos de prueba :
"Parte2Ejemplo1.txt" (1 ciclo)
"Parte2Ejemplo1.txt" (2 ciclos de dos componentes distintas)

Para la parte III:
El algoritmo que implementa DFS para hallar ciclos se ejecuta desde la 
clase Main dentro del paquete "Parte III" pasando por argumento por 
linea de comandos el nombre del archivo que se va a ejecutar, 
se tienen 2 archivos de prueba :
"Parte3Ejemplo1.txt" (3 componentes)
"Parte3Ejemplo1.txt" (1 componente)
